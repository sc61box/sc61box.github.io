"""SHARP SC61860(ESR-H)のCPUコア

命令の意味とサイクル数はMAMEの実装にならい、次の命令だけ変えた。

* 56h(READ)・54h(READM): 1バイト命令。次の番地のバイトをAか(P)に読み、そのバイトは
  命令として残す(MAMEは2バイト命令)。LC-3コンパイラは、READMの次のバイトを命令として
  実行させている。
* LOOP: 抜けるときだけスタックの回数を捨てる(MAMEは飛ぶたびに捨てる)。
* WAIT n: 6+nサイクル(MAMEは9+2n)。
* CUP・CDN: 待つあいだPを1つずつ増やし、終わったときXinが0ならZを立てる(MAMEは(P)を
  増やし、ZにXinを入れる)。
* IYS・DYSは6サイクル、PTCは8、DTCは5+7d。
* ANID・ORID・TSID: 書き換える前の(DP)を(R-1)に置く。
* 72h・73h・76h・77h(LIIH n): 2バイト命令で、I=H、H=n、Z=0。
  「走れ!セコイライン」COR版が「72 00」をI=0の意味で使っている。MAMEは何もしない。
* ADN・SBN・ADW・SBW: 1バイトごとに2進で足し引きしてから、Z80のDAAと同じ補正をする
  (MAMEは桁ごとに10進で計算する)。10進でない桁(A〜F)を含むときに答えが違う。PC-1350の
  BASICは&0を読むとき、指数にFの桁を置いたままSBNで1を引く。

CUP・CDNの動きは、ROMのカセットの読み書きが正しく動くことで確かめた。
"""

from .i18n import tr

A, B, I, J = 2, 3, 0, 1
CUP_STEP = 4  # CUP・CDNでPを1つ進めるのにかかるサイクル
XL, XH, YL, YH = 4, 5, 6, 7
K, L, M, N = 8, 9, 10, 11
IA, IB, FO, CP = 0x5C, 0x5D, 0x5E, 0x5F  # 入出力バッファ


class Bus:
    """メモリと入出力(machine.PC1251が実装する)"""

    def read(self, a: int) -> int:
        raise NotImplementedError

    def write(self, a: int, v: int) -> None:
        raise NotImplementedError

    def in_a(self) -> int:
        return 0

    def in_b(self) -> int:
        return 0

    def out_a(self, v: int) -> None:
        pass

    def out_b(self, v: int) -> None:
        pass

    def out_c(self, v: int) -> None:
        pass

    def out_f(self, v: int) -> None:
        pass

    def test_bits(self) -> int:
        """TEST命令で見える信号(ビット0が512ms、1が2ms、3がBRK、6がRESET、7がXin)"""
        return 0

    def test(self, n: int) -> int:
        """TEST nで見えるビット。読んだときに消える信号があれば、ここで消す"""
        return self.test_bits() & n

    def xin(self, cycle: int) -> int:
        """サイクルcycleでのカセット入力(0か1)"""
        return 0


def _bcd_add(dst: int, src: int, carry: int) -> tuple[int, int]:
    """2進で足してから10進に補正する(Z80のDAAと同じ補正)"""
    r = dst + src + carry
    half = (dst & 0x0F) + (src & 0x0F) + carry > 0x0F
    c = 1 if r > 0xFF else 0
    v = r & 0xFF
    if (v & 0x0F) > 9 or half:
        r = v + 6
    else:
        r = v
    if v > 0x99 or c:
        r += 0x60
        c = 1
    return r & 0xFF, c


def _bcd_sub(dst: int, src: int, borrow: int) -> tuple[int, int]:
    """2進で引いてから10進に補正する(Z80のDAAと同じ補正。8086のDASと違い、6を引いたときの
    借りではキャリーを立てない)"""
    r = dst - src - borrow
    half = (dst & 0x0F) - (src & 0x0F) - borrow < 0
    c = 1 if r < 0 else 0
    v = r & 0xFF
    if (v & 0x0F) > 9 or half:
        r = v - 6
    else:
        r = v
    if v > 0x99 or c:
        r -= 0x60
        c = 1
    return r & 0xFF, c


class SC61860:
    def __init__(self, bus: Bus, ratio: tuple[int, int] = (1, 1)):
        self.bus = bus
        self.ram = bytearray(0x80)  # 内部RAM(96バイト+Pが指せる残り)
        # cyclesは周辺(タイマ、音、カセット)と共通の時刻で、1秒が192000。クロックの速い機種
        # (PC-1261などは768kHz)では、命令のサイクル数をratio(分子, 分母)倍して足す
        self.ratio = ratio
        self._frac = 0
        self.cycles = 0
        self.trapped = False  # runがguardの番地で止まったか
        self.reset()
        self._ops = [self._build(op) for op in range(256)]

    def reset(self) -> None:
        """レジスタを初めの値にする。cyclesは戻さない(周辺と共通の時刻なので、RESETやONのあとも
        進み続ける。戻すと、キーの打ち込みなど、時刻で待っているものがいつまでも終わらない)"""
        self.pc = 0
        self.dp = 0
        self.p = self.q = self.r = 0
        self.c = self.z = 0
        self.h = 0  # PTCで積む件数
        self.hreg = 0  # LIIHが読み書きするHレジスタ

    REGISTERS = ("pc", "dp", "p", "q", "r", "c", "z", "h", "hreg", "cycles", "_frac")

    def state(self) -> dict:
        """レジスタと内部RAM(状態の保存用)"""
        out = {name: getattr(self, name) for name in self.REGISTERS}
        out["ram"] = self.ram.hex()
        return out

    # 状態のファイルから読む値の上限(cyclesは上限なし)
    _LIMITS = {"pc": 0xFFFF, "dp": 0xFFFF, "p": 0x7F, "q": 0x7F, "r": 0x7F, "c": 1, "z": 1}
    _LIMITS |= {"h": 0xFF, "hreg": 0xFF}

    def check_state(self, state: object) -> dict:
        """stateの値を確かめて、set_stateに渡せる形にして返す。おかしければValueError"""
        if not isinstance(state, dict):
            raise ValueError(tr("cpu.no_cpu_state"))
        out: dict[str, int | bytes] = {}
        for name in self.REGISTERS:
            v = state.get(name)
            if type(v) is not int or v < 0:
                raise ValueError(tr("cpu.bad_value_cpu", name=name))
            if name == "_frac":
                if v >= self.ratio[1]:
                    raise ValueError(tr("cpu.bad_value_cpu", name=name))
            elif v > self._LIMITS.get(name, v):
                raise ValueError(tr("cpu.bad_value_cpu", name=name))
            out[name] = v
        try:
            ram = bytes.fromhex(state.get("ram", ""))
        except (TypeError, ValueError):
            ram = b""
        if len(ram) != len(self.ram):
            raise ValueError(tr("cpu.cpu_internal_ram_size"))
        out["ram"] = ram
        return out

    def set_state(self, state: dict) -> None:
        """check_stateで確かめた値に戻す"""
        for name in self.REGISTERS:
            setattr(self, name, state[name])
        self.ram[:] = state["ram"]

    # ---- 補助 ----
    def _fetch(self) -> int:
        v = self.bus.read(self.pc)
        self.pc = (self.pc + 1) & 0xFFFF
        return v

    def _fetch16(self) -> int:
        hi = self._fetch()
        return (hi << 8) | self._fetch()

    def push(self, v: int) -> None:
        self.r = (self.r - 1) & 0x7F
        self.ram[self.r] = v & 0xFF

    def pop(self) -> int:
        v = self.ram[self.r]
        self.r = (self.r + 1) & 0x7F
        return v

    def step(self) -> int:
        """1命令を実行して、進んだ時刻(サイクル)を返す"""
        op = self._fetch()
        n = self._ticks(self._ops[op]())
        self.cycles += n
        return n

    def _ticks(self, n: int) -> int:
        """CPUのサイクル数を時刻の単位に直す"""
        num, den = self.ratio
        if num == den:
            return n
        self._frac += n * num
        q = self._frac // den
        self._frac -= q * den
        return q

    def run(
        self, cycles: int, guard: bytearray | None = None, seen: bytearray | None = None
    ) -> int:
        """cyclesぶん実行し、実際に進んだサイクル数を返す。ポートへの書き込みの時刻を
        周辺がcyclesで読むので、cyclesは命令ごとに進める。

        guard(番地ごとのバイト列)を渡すと、命令を読む前にPCの番地を見て、0でなければ
        その命令を実行せずに止まり、trappedをTrueにする(マシン語の作業欄のブレークポイント)。
        seen(番地ごとのバイト列)を渡すと、命令を読んだPCの番地に1を書く(作業欄の
        逆アセンブルで、実行した命令を見分けるのに使う)"""
        ops = self._ops
        fetch = self._fetch
        start = self.cycles
        end = start + cycles
        self.trapped = False
        if guard is not None and seen is not None:
            ticks = self._ticks
            while self.cycles < end:
                pc = self.pc
                if guard[pc]:
                    self.trapped = True
                    break
                seen[pc] = 1
                self.cycles += ticks(ops[fetch()]())
            return self.cycles - start
        if guard is not None:
            ticks = self._ticks
            while self.cycles < end:
                if guard[self.pc]:
                    self.trapped = True
                    break
                self.cycles += ticks(ops[fetch()]())
            return self.cycles - start
        if seen is not None:
            ticks = self._ticks
            while self.cycles < end:
                seen[self.pc] = 1
                self.cycles += ticks(ops[fetch()]())
            return self.cycles - start
        if self.ratio[0] == self.ratio[1]:
            while self.cycles < end:
                self.cycles += ops[fetch()]()
        else:
            ticks = self._ticks
            while self.cycles < end:
                self.cycles += ticks(ops[fetch()]())
        return self.cycles - start

    # ---- 命令表 ----
    def _build(self, op: int):  # noqa: C901 (命令表は長くなる)
        s = self
        ram = s.ram
        bus = s.bus
        rd, wr = bus.read, bus.write

        if 0x80 <= op <= 0xBF:  # LP l
            v = op & 0x3F

            def f():
                s.p = v
                return 2

            return f
        if op >= 0xE0:  # CAL ln
            hi = (op & 0x1F) << 8

            def f():
                a = hi | s._fetch()
                s.push(s.pc >> 8)
                s.push(s.pc & 0xFF)
                s.pc = a
                return 7

            return f

        def imm(reg):
            def f():
                ram[reg] = s._fetch()
                return 4

            return f

        def incdec_ptr(lo, d, mode):
            hi = lo + 1

            def f():
                v = ram[lo] + d
                ram[lo] = v & 0xFF
                if v > 0xFF or v < 0:
                    ram[hi] = (ram[hi] + d) & 0xFF
                s.dp = ram[lo] | (ram[hi] << 8)
                s.q = hi
                if mode == 0:
                    return 6
                if mode == 1:
                    ram[A] = rd(s.dp)
                    return 7
                wr(s.dp, ram[A])
                return 6

            return f

        def inc(reg):
            def f():
                v = (ram[reg] + 1) & 0xFF
                ram[reg] = v
                s.q = reg
                s.z = int(v == 0)
                s.c = int(v == 0)
                return 4

            return f

        def dec(reg):
            def f():
                v = (ram[reg] - 1) & 0xFF
                ram[reg] = v
                s.q = reg
                s.z = int(v == 0)
                s.c = int(v == 0xFF)
                return 4

            return f

        def jr(cond, plus):
            def f():
                base = s.pc
                n = s._fetch()
                if cond():
                    s.pc = (base + n if plus else base - n) & 0xFFFF
                    return 7
                return 4

            return f

        def jp(cond):
            def f():
                a = s._fetch16()
                if cond():
                    s.pc = a
                return 6

            return f

        always = lambda: True  # noqa: E731
        is_z = lambda: s.z  # noqa: E731
        nz = lambda: not s.z  # noqa: E731
        is_c = lambda: s.c  # noqa: E731
        nc = lambda: not s.c  # noqa: E731

        def copy(lenreg):
            def f():
                n = ram[lenreg]
                for _ in range(n + 1):
                    ram[s.p] = ram[s.q]
                    s.p = (s.p + 1) & 0x7F
                    s.q = (s.q + 1) & 0x7F
                return 5 + 2 * n

            return f

        def exch(lenreg):
            def f():
                n = ram[lenreg]
                for _ in range(n + 1):
                    ram[s.p], ram[s.q] = ram[s.q], ram[s.p]
                    s.p = (s.p + 1) & 0x7F
                    s.q = (s.q + 1) & 0x7F
                return 6 + 3 * n

            return f

        def copy_ext(lenreg):
            def f():
                n = ram[lenreg]
                for i in range(n + 1):
                    ram[s.p] = rd(s.dp)
                    s.p = (s.p + 1) & 0x7F
                    if i != n:
                        s.dp = (s.dp + 1) & 0xFFFF
                return 5 + 4 * n

            return f

        def exch_ext(lenreg):
            def f():
                n = ram[lenreg]
                for i in range(n + 1):
                    t = ram[s.p]
                    ram[s.p] = rd(s.dp)
                    wr(s.dp, t)
                    s.p = (s.p + 1) & 0x7F
                    if i != n:
                        s.dp = (s.dp + 1) & 0xFFFF
                return 7 + 6 * n

            return f

        def bcd_a(sub):
            def f():
                n = ram[I]
                src = ram[A]
                c = 0
                zero = 1
                for _ in range(n + 1):
                    if sub:
                        v, c = _bcd_sub(ram[s.p], src, c)
                    else:
                        v, c = _bcd_add(ram[s.p], src, c)
                    ram[s.p] = v
                    if v:
                        zero = 0
                    s.p = (s.p - 1) & 0x7F
                    src = 0
                s.c, s.z = c, zero
                return 7 + 3 * n

            return f

        def bcd_q(sub):
            def f():
                n = ram[I]
                c = 0
                zero = 1
                for _ in range(n + 1):
                    if sub:
                        v, c = _bcd_sub(ram[s.p], ram[s.q], c)
                    else:
                        v, c = _bcd_add(ram[s.p], ram[s.q], c)
                    ram[s.p] = v
                    if v:
                        zero = 0
                    s.p = (s.p - 1) & 0x7F
                    s.q = (s.q - 1) & 0x7F
                s.q = (s.q - 1) & 0x7F
                s.c, s.z = c, zero
                return 7 + 3 * n

            return f

        def add_to(reg_fn, val_fn, carry=False, sub=False, cyc=3):
            def f():
                a = reg_fn()
                v = val_fn()
                if sub:
                    t = ram[a] - v - (s.c if carry else 0)
                    s.c = int(t < 0)
                else:
                    t = ram[a] + v + (s.c if carry else 0)
                    s.c = int(t > 0xFF)
                t &= 0xFF
                ram[a] = t
                s.z = int(t == 0)
                return cyc

            return f

        def logic(reg_fn, val_fn, kind, cyc):
            def f():
                a = reg_fn()
                v = val_fn()
                if kind == "and":
                    t = ram[a] & v
                    ram[a] = t
                elif kind == "or":
                    t = ram[a] | v
                    ram[a] = t
                else:  # test
                    t = ram[a] & v
                s.z = int(t == 0)
                return cyc

            return f

        def cmp(reg_fn, val_fn, cyc):
            def f():
                t = ram[reg_fn()] - val_fn()
                s.z = int(t == 0)
                s.c = int(t < 0)
                return cyc

            return f

        P = lambda: s.p  # noqa: E731
        RA = lambda: A  # noqa: E731
        IMM = s._fetch
        VA = lambda: ram[A]  # noqa: E731

        def ext_logic(kind):
            def f():
                n = s._fetch()
                v = rd(s.dp)
                ram[(s.r - 1) & 0x7F] = v  # (R-1)を一時的な置き場に使う
                if kind == "and":
                    v &= n
                    wr(s.dp, v)
                elif kind == "or":
                    v |= n
                    wr(s.dp, v)
                else:
                    v &= n
                s.z = int(v == 0)
                return 6

            return f

        def simple(fn, cyc):
            def f():
                fn()
                return cyc

            return f

        def g_ldp():
            ram[A] = s.p

        def g_ldq():
            ram[A] = s.q

        def g_ldr():
            ram[A] = s.r

        def g_stp():
            s.p = ram[A] & 0x7F

        def g_stq():
            s.q = ram[A] & 0x7F

        def g_str():
            s.r = ram[A] & 0x7F

        # --- 各オペコード ---
        if op == 0x00:
            return imm(I)
        if op == 0x01:
            return imm(J)
        if op == 0x02:
            return imm(A)
        if op == 0x03:
            return imm(B)
        if op == 0x04:
            return incdec_ptr(XL, 1, 0)
        if op == 0x05:
            return incdec_ptr(XL, -1, 0)
        if op == 0x06:
            return incdec_ptr(YL, 1, 0)
        if op == 0x07:
            return incdec_ptr(YL, -1, 0)
        if op == 0x08:
            return copy(I)
        if op == 0x09:
            return exch(I)
        if op == 0x0A:
            return copy(J)
        if op == 0x0B:
            return exch(J)
        if op == 0x0C:
            return bcd_a(False)
        if op == 0x0D:
            return bcd_a(True)
        if op == 0x0E:
            return bcd_q(False)
        if op == 0x0F:
            return bcd_q(True)
        if op == 0x10:  # LIDP nm

            def f():
                s.dp = s._fetch16()
                return 8

            return f
        if op == 0x11:  # LIDL n

            def f():
                s.dp = (s.dp & 0xFF00) | s._fetch()
                return 5

            return f
        if op == 0x12:  # LIP n

            def f():
                s.p = s._fetch() & 0x7F
                return 4

            return f
        if op == 0x13:  # LIQ n

            def f():
                s.q = s._fetch() & 0x7F
                return 4

            return f
        if op in (0x14, 0x15):  # ADB / SBB
            sub = op == 0x15

            def f():
                p0 = s.p
                p1 = (p0 + 1) & 0x7F
                if sub:
                    t = ram[p0] - ram[A]
                    t2 = ram[p1] - ram[B] - (1 if t < 0 else 0)
                    s.c = int(t2 < 0)
                else:
                    t = ram[p0] + ram[A]
                    t2 = ram[p1] + ram[B] + (1 if t > 0xFF else 0)
                    s.c = int(t2 > 0xFF)
                ram[p0] = t & 0xFF
                ram[p1] = t2 & 0xFF
                s.z = int(ram[p0] == 0 and ram[p1] == 0)
                s.p = p1
                return 5

            return f
        if op == 0x18:
            return copy_ext(I)
        if op == 0x19:
            return exch_ext(I)
        if op == 0x1A:
            return copy_ext(J)
        if op == 0x1B:
            return exch_ext(J)
        if op == 0x1C:  # SRW

            def f():
                n = ram[I]
                t = 0
                for _ in range(n + 1):
                    t |= ram[s.p]
                    ram[s.p] = (t >> 4) & 0xFF
                    s.p = (s.p + 1) & 0x7F
                    t = (t << 8) & 0xF00
                return 5 + n

            return f
        if op == 0x1D:  # SLW

            def f():
                n = ram[I]
                t = 0
                for _ in range(n + 1):
                    t |= ram[s.p] << 4
                    ram[s.p] = t & 0xFF
                    s.p = (s.p - 1) & 0x7F
                    t >>= 8
                return 5 + n

            return f
        if op == 0x1E:  # FILM

            def f():
                n = ram[I]
                for _ in range(n + 1):
                    ram[s.p] = ram[A]
                    s.p = (s.p + 1) & 0x7F
                return 5 + n

            return f
        if op == 0x1F:  # FILD

            def f():
                n = ram[I]
                for i in range(n + 1):
                    wr(s.dp, ram[A])
                    if i != n:
                        s.dp = (s.dp + 1) & 0xFFFF
                return 4 + 3 * n

            return f
        if op == 0x20:
            return simple(g_ldp, 2)
        if op == 0x21:
            return simple(g_ldq, 2)
        if op == 0x22:
            return simple(g_ldr, 2)
        if op == 0x23:  # CLRA

            def f():
                ram[A] = 0
                return 2

            return f
        if op == 0x24:
            return incdec_ptr(XL, 1, 1)
        if op == 0x25:
            return incdec_ptr(XL, -1, 1)
        if op == 0x26:
            return incdec_ptr(YL, 1, 2)
        if op == 0x27:
            return incdec_ptr(YL, -1, 2)
        if op == 0x28:
            return jr(nz, True)
        if op == 0x29:
            return jr(nz, False)
        if op == 0x2A:
            return jr(nc, True)
        if op == 0x2B:
            return jr(nc, False)
        if op == 0x2C:
            return jr(always, True)
        if op == 0x2D:
            return jr(always, False)
        if op == 0x2F:  # LOOP n

            def f():
                base = s.pc
                n = s._fetch()
                t = (ram[s.r] - 1) & 0xFF
                ram[s.r] = t
                s.z = int(t == 0)
                s.c = int(t == 0xFF)
                if not s.c:
                    s.pc = (base - n) & 0xFFFF
                    return 10
                s.pop()  # 抜けるときに回数を捨てる
                return 7

            return f
        if op == 0x30:
            return simple(g_stp, 2)
        if op == 0x31:
            return simple(g_stq, 2)
        if op == 0x32:
            return simple(g_str, 2)
        if op == 0x34:  # PUSH

            def f():
                s.push(ram[A])
                return 3

            return f
        if op == 0x35:  # DATA

            def f():
                n = ram[I]
                for i in range(n + 1):
                    ram[s.p] = rd((ram[B] << 8) | ram[A])
                    s.p = (s.p + 1) & 0x7F
                    if i != n:
                        v = ram[A] + 1
                        ram[A] = v & 0xFF
                        if v > 0xFF:
                            ram[B] = (ram[B] + 1) & 0xFF
                return 11 + 4 * n

            return f
        if op == 0x37:  # RTN

            def f():
                lo = s.pop()
                s.pc = lo | (s.pop() << 8)
                return 4

            return f
        if op == 0x38:
            return jr(is_z, True)
        if op == 0x39:
            return jr(is_z, False)
        if op == 0x3A:
            return jr(is_c, True)
        if op == 0x3B:
            return jr(is_c, False)
        if op == 0x40:
            return inc(I)
        if op == 0x41:
            return dec(I)
        if op == 0x42:
            return inc(A)
        if op == 0x43:
            return dec(A)
        if op == 0x44:
            return add_to(P, VA)
        if op == 0x45:
            return add_to(P, VA, sub=True)
        if op == 0x46:
            return logic(P, VA, "and", 3)
        if op == 0x47:
            return logic(P, VA, "or", 3)
        if op == 0x48:
            return inc(K)
        if op == 0x49:
            return dec(K)
        if op == 0x4A:
            return inc(M)
        if op == 0x4B:
            return dec(M)
        if op == 0x4C:  # INA

            def f():
                v = bus.in_a() & 0xFF
                ram[A] = v
                s.z = int(v == 0)
                return 2

            return f
        if op == 0x4D:  # NOPW
            return lambda: 2
        if op == 0x4E:  # WAIT n

            def f():
                return 6 + s._fetch()

            return f
        if op in (0x4F, 0x6F):  # CUP / CDN (Xinの変化を待つ)
            level = 1 if op == 0x6F else 0

            def f():
                # ROMは待った長さをあとでLDPで読む
                n = ram[I]
                num, den = s.ratio
                cyc = 1
                x = bus.xin(s.cycles + cyc * num // den)
                for _ in range(n + 1):
                    s.p = (s.p + 1) & 0x7F
                    cyc += CUP_STEP
                    x = bus.xin(s.cycles + cyc * num // den)
                    if x != level:
                        break
                s.z = int(x == 0)  # 待ちきれずに終わったかをROMがJPZで見る
                return cyc

            return f
        if op == 0x50:  # INCP

            def f():
                s.p = (s.p + 1) & 0x7F
                return 2

            return f
        if op == 0x51:  # DECP

            def f():
                s.p = (s.p - 1) & 0x7F
                return 2

            return f
        if op == 0x52:  # STD

            def f():
                wr(s.dp, ram[A])
                return 2

            return f
        if op == 0x53:  # MVDM (DP)←(P)

            def f():
                wr(s.dp, ram[s.p])
                return 3

            return f
        if op == 0x54:  # READM (P)←(PC+1)。PCは進めない

            def f():
                ram[s.p] = rd(s.pc)
                return 3

            return f
        if op == 0x55:  # MVMD (P)←(DP)

            def f():
                ram[s.p] = rd(s.dp)
                return 3

            return f
        if op == 0x56:  # READ A←(PC+1)。PCは進めない

            def f():
                ram[A] = rd(s.pc)
                return 3

            return f
        if op == 0x57:  # LDD

            def f():
                ram[A] = rd(s.dp)
                return 3

            return f
        if op == 0x58:  # SWP

            def f():
                t = ram[A]
                ram[A] = ((t << 4) | (t >> 4)) & 0xFF
                return 2

            return f
        if op == 0x59:  # LDM

            def f():
                ram[A] = ram[s.p]
                return 2

            return f
        if op == 0x5A:  # SL

            def f():
                t = (ram[A] << 1) | s.c
                s.c = t >> 8
                ram[A] = t & 0xFF
                return 2

            return f
        if op == 0x5B:  # POP

            def f():
                ram[A] = s.pop()
                return 2

            return f
        if op == 0x5D:  # OUTA

            def f():
                s.q = IA
                bus.out_a(ram[IA])
                return 3

            return f
        if op == 0x5F:  # OUTF

            def f():
                s.q = FO
                bus.out_f(ram[FO])
                return 3

            return f
        if op == 0x60:
            return logic(P, IMM, "and", 4)
        if op == 0x61:
            return logic(P, IMM, "or", 4)
        if op == 0x62:
            return logic(P, IMM, "test", 4)
        if op == 0x63:
            return cmp(P, IMM, 4)
        if op == 0x64:
            return logic(RA, IMM, "and", 4)
        if op == 0x65:
            return logic(RA, IMM, "or", 4)
        if op == 0x66:
            return logic(RA, IMM, "test", 4)
        if op == 0x67:
            return cmp(RA, IMM, 4)
        if op == 0x69:  # DTC

            def f():
                cyc = 5 + 7 * s.h
                for _ in range(s.h):
                    v = s._fetch()
                    a = s._fetch16()
                    s.z = int(v == ram[A])
                    if s.z:
                        s.pc = a
                        return cyc
                s.pc = s._fetch16()
                return cyc

            return f
        if op == 0x6B:  # TEST n

            def f():
                n = s._fetch()
                s.z = int(bus.test(n) == 0)
                return 4

            return f
        if op == 0x70:
            return add_to(P, IMM, cyc=4)
        if op == 0x71:
            return add_to(P, IMM, sub=True, cyc=4)
        if op == 0x74:
            return add_to(RA, IMM, cyc=4)
        if op == 0x75:
            return add_to(RA, IMM, sub=True, cyc=4)
        if op == 0x78:  # CALL nm

            def f():
                a = s._fetch16()
                s.push(s.pc >> 8)
                s.push(s.pc & 0xFF)
                s.pc = a
                return 8

            return f
        if op == 0x79:
            return jp(always)
        if op == 0x7A:  # PTC h,nm

            def f():
                s.h = s._fetch()
                a = s._fetch16()
                s.push(a >> 8)
                s.push(a & 0xFF)
                return 8

            return f
        if op == 0x7C:
            return jp(nz)
        if op == 0x7D:
            return jp(nc)
        if op == 0x7E:
            return jp(is_z)
        if op == 0x7F:
            return jp(is_c)
        if op == 0xC0:
            return inc(J)
        if op == 0xC1:
            return dec(J)
        if op == 0xC2:
            return inc(B)
        if op == 0xC3:
            return dec(B)
        if op == 0xC4:
            return add_to(P, VA, carry=True)
        if op == 0xC5:
            return add_to(P, VA, carry=True, sub=True)
        if op == 0xC6:  # TSMA (P)&A
            return logic(P, VA, "test", 3)
        if op == 0xC7:
            return cmp(P, VA, 3)
        if op == 0xC8:
            return inc(L)
        if op == 0xC9:
            return dec(L)
        if op == 0xCA:
            return inc(N)
        if op == 0xCB:
            return dec(N)
        if op == 0xCC:  # INB

            def f():
                v = bus.in_b() & 0xFF
                ram[A] = v
                s.z = int(v == 0)
                return 2

            return f
        if op == 0xCE:  # NOPT
            return lambda: 3
        if op == 0xD0:  # SC

            def f():
                s.c = 1
                s.z = 1
                return 2

            return f
        if op == 0xD1:  # RC

            def f():
                s.c = 0
                s.z = 1
                return 2

            return f
        if op == 0xD2:  # SR

            def f():
                t = ram[A] | (s.c << 8)
                s.c = t & 1
                ram[A] = t >> 1
                return 2

            return f
        if op == 0xD4:
            return ext_logic("and")
        if op == 0xD5:
            return ext_logic("or")
        if op == 0xD6:
            return ext_logic("test")
        if op == 0xD8:  # LEAVE

            def f():
                ram[s.r] = 0
                return 2

            return f
        if op == 0xDA:  # EXAB

            def f():
                ram[A], ram[B] = ram[B], ram[A]
                return 3

            return f
        if op == 0xDB:  # EXAM

            def f():
                ram[A], ram[s.p] = ram[s.p], ram[A]
                return 3

            return f
        if op == 0xDD:  # OUTB

            def f():
                s.q = IB
                bus.out_b(ram[IB])
                return 2

            return f
        if op == 0xDF:  # OUTC

            def f():
                s.q = CP
                bus.out_c(ram[CP])
                return 2

            return f
        if op in (0x72, 0x73, 0x76, 0x77):  # LIIH n

            def f():
                ram[I] = s.hreg
                s.hreg = s._fetch()
                s.z = 0
                return 2

            return f
        # 動作のわからない命令は何もしない
        return lambda: 2
