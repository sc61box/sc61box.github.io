# title: もぐらたたき(PC-インタープリタ)
# norom: basic
# model: 1251,1245
# hex: pcint.hex
# run: RUN 900
# PiO 1986年8月号「PC-インタープリタ」(Fan_PC-1251氏作)のリスト2。作者の了解を得て収めている。
# エミュレータのMITライセンスには含まれない。
# 1〜6の穴からもぐらが出るので、出た穴の数字キーを押す。3段目まで出きる前に押せないとGAME OVER。
# 当てるたびに速くなる。RUN 900(またはDEF =)で始め、終わると得点が出る。
5 CLEAR:COS:W=64
10 PRINT "= 1 2 3 4 5 6 = PC-1251"
12 B=01+RND 06:A=B*0A:C=40+B
14 BEEP 08,30:DEG A,40,60,60,60,40
15 WAIT W:IF INKEY$=C GOTO 40
17 BEEP 05,30:DEG A,70,58,78,58,70
18 WAIT W:IF INKEY$=C GOTO 40
20 BEEP 04,40:DEG A,7C,76,7E,76,7C
21 WAIT W:IF INKEY$=C GOTO 40
30 FOR 12:SQR:WAIT 04:BEEP 03,20:NEXT:CALL 01:PRINT "GAME OVER ":STOP:END
40 BEEP 09,20:BEEP 03,30:W=W-01:Z=Z+01:GOTO 10
900 "="CALL &C300:PRINT "SCORE=";STR$ PEEK &C69F
